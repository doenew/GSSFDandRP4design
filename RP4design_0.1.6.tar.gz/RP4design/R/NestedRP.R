#' Nested Representative Points based on energy distance
#'
#' This function implements a Generate a set of representative points with nested structures D_1⊆D_2⊆D_K based on the given training samples
#' It uses a MM algorithm with parallel computation capabilities for improved performance.
#'
#' @param nv A vector of integers representing the number of points in each layer.
#' @param ts A matrix representing the training sample.
#' @param lambda A numerical weight vector is used to describe the importance of the representativeness of each layer's point set Default is 1/length(nv).
#' @param weights Vector of weights if importance sampling methods is used (default: 1)
#' @param T An integer for the number of iterations. Default is 300.
#' @param ifparallel A logical indicating whether to use parallel computation. Default is TRUE.
#' @param nthreads An integer for the number of threads to use in parallel computation.
#'                 If NULL, uses all available cores minus one. Default is NULL.
#' @importFrom parallel detectCores makeCluster stopCluster
#' @importFrom foreach foreach %dopar%
#' @importFrom doParallel registerDoParallel
#' @importFrom Rcpp evalCpp sourceCpp
#' @useDynLib RP4design
#' @return A list containing two elements:
#' \item{PnK}{A matrix of the topmost representative point set (the one with the most points);}
#' \item{layer}{A vector indicating the mark of each new point generated in each layer.}
#'
#' @examples
#' \donttest{
#' # Generate training sample
#' set.seed(123)
#' nv <- c(10, 20, 40)
#' # training sample
#' ts <- matrix(runif(200000), ncol = 2)
#' # or quasi monte carlo
#' # if (!require("randtoolbox")) install.packages("randtoolbox")
#' # ts <- sobol(100000, 2, scrambling = 3)
#'
#' # Run the algorithm
#' D <- NestedRP(nv, ts)
#'
#' # View results
#' plot(D$PnK[1:nv[1],],col=D$layer[1:nv[1]],pch=D$layer[1:nv[1]]+15,cex=2,xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' points(D$PnK[(nv[1]+1):nv[2],],col=D$layer[(nv[1]+1):nv[2]],pch=D$layer[(nv[1]+1):nv[2]]+15,cex=2)
#' points(D$PnK[(nv[2]+1):nv[3],],col=D$layer[(nv[2]+1):nv[3]],pch=D$layer[(nv[2]+1):nv[3]]+15,cex=2)
#'
#' # Generalized Nested Representative Points
#'
#' # Run the algorithm
#' D <- NestedRP(nv, ts, weights =apply(dbeta(ts,1,1),1,prod))
#'
#' # View results
#' plot(D$PnK[1:nv[1],],col=D$layer[1:nv[1]],pch=D$layer[1:nv[1]]+15,cex=2,xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' points(D$PnK[(nv[1]+1):nv[2],],col=D$layer[(nv[1]+1):nv[2]],pch=D$layer[(nv[1]+1):nv[2]]+15,cex=2)
#' points(D$PnK[(nv[2]+1):nv[3],],col=D$layer[(nv[2]+1):nv[3]],pch=D$layer[(nv[2]+1):nv[3]]+15,cex=2)
#'
#' }
#'
#' @export
NestedRP <- function(nv, ts, lambda = 1/length(nv), weights = 1,T = 300,
                     ifparallel = TRUE, nthreads = NULL) {
  # Input validation
  if (!is.vector(nv) || !all(nv > 0) || !all(diff(nv) > 0)) {
    stop("nv must be a positive increasing vector")
  }

  if (!is.matrix(ts) || nrow(ts) < max(nv)) {
    stop("ts must be a matrix with at least max(nv) rows")
  }

  K <- length(nv) # K layers
  neachlayer <- c(nv[1], nv[2:K] - nv[1:(K-1)])
  z <- rep(1:K, times = neachlayer) # It means which layer is each point added

  # Initial points
  N <- nrow(ts) # the number of points in training sample
  p <- ncol(ts) # dimension
  n <- nv[K] # The number of points in the maximum point set
  wv <- lambda / nv

  # Sample initial points
  Pn <- ts[sample(1:N, n, replace = FALSE), ]

  # Set number of threads
  if (ifparallel) {
    if (is.null(nthreads)) {
      nthreads <- max(1, parallel::detectCores() - 1)
    }
    message(paste("Parallel computing with", nthreads, "threads"))
  } else {
    nthreads <- 1
  }

  # Transpose training samples for efficient computation
  trts <- t(ts)
  # Process weights parameter
  if (length(weights) == 1) {
    weights_vec <- rep(weights, N)
  } else if (length(weights) != N) {
    stop("Length of weights must be 1 or equal to the number of training samples")
  } else {
    weights_vec <- as.vector(weights)
  }
  emojis <- c(
    "\U1F634",
    "\U1F60A",
    "\U1F60E",
    "\U1F680",
    "\U1F389"
  )
  # MM algorithm iteration
  for (t in 1:T) {
    Pn <- nested_rpew_core(Pn, trts, z, nv, wv,weights_vec, K, nthreads)

    progress <- round(t/T * 100)
    emoji_index <- min(ceiling(progress/20), length(emojis))

    cat(sprintf("\r Progress: %3d%% %s", progress, emojis[emoji_index]))
    flush.console()
  }

  return(list(PnK = Pn, layer = z))
}
