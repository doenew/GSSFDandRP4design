#' Sequential Sliced Representative Points with Weighted Hybrid Energy Distance Criterion
#'
#' This function implements sequential sliced representative points based on the weighted
#' hybrid energy distance criterion with parallel computation support.
#'
#' @param nv Vector specifying number of points in each slice, or total number of points
#' @param expo Existing points (default: NULL)
#' @param K Number of slices with newly added points (default: length(nv))
#' @param ts Training sample matrix
#' @param lambda Vector of lambda parameters for each slice (default: NULL, auto-computed)
#' @param weights Vector of weights for training samples
#' @param T Maximum number of iterations (default: 300)
#' @param n_cores Number of CPU cores for parallel computation (default: NULL, uses detectCores() - 1)
#' @param use_cpp Logical, whether to use C++ implementation (default: TRUE)
#'
#' @return List containing:
#'   \item{Pn}{Matrix of representative points}
#'   \item{slicenumber}{Vector indicating slice membership for each point}
#'
#' @examples
#' \dontrun{
#' if (!require("randtoolbox")) install.packages("randtoolbox")
#' set.seed(123)
#' ts <- sobol(100000, 2, scrambling = 3)
#' # sliced space-filling design with 3 slices (n1=10,n2=20,n3=30)
#' result1 <- SeqslicedRP(c(10, 10, 10), ts = ts,
#'                       T = 300)
#' plot(result1$Pn, col = result1$slicenumber, pch = result1$slicenumber + 15,
#'      cex = 2, xlim = c(0, 1), ylim = c(0, 1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' # Generalized (weighted) sliced space-filling design
#' weights =apply(dbeta(ts,0.5,0.5),1,prod)
#' result2 <- SeqslicedRP(c(10, 20, 30), ts = ts, weights = weights,T = 300)
#'
#' plot(result2$Pn, col = result2$slicenumber, pch = result2$slicenumber + 15,
#'      cex = 2, xlim = c(0, 1), ylim = c(0, 1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#'
#' # 30 existing points as the first slice
#' expo_points <- result1$Pn
#' # Generate 2 new slices with 10 points each based on existing points
#' result3 <- SeqslicedRP(nv = c(10, 10), expo = expo_points,
#'                      ts = ts, T = 300)
#' plot(result3$Pn, col = result3$slicenumber, pch = result3$slicenumber + 15,
#'      cex = 2, xlim = c(0, 1), ylim = c(0, 1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' }
#'
#' @importFrom parallel detectCores makeCluster stopCluster
#' @importFrom foreach foreach %dopar%
#' @importFrom doParallel registerDoParallel
#' @export
SeqslicedRP <- function(nv, expo = NULL, K = length(nv), ts, lambda = NULL, weights = 1,
                        T = 300, n_cores = NULL, use_cpp = TRUE) {

  # Handle cases with existing point sets
  if (!is.null(expo)) {
    if (!is.matrix(expo) && !is.data.frame(expo)) {
      stop("expo must be a matrix or data.frame")
    }
    expo <- as.matrix(expo)
    nexp <- nrow(expo)  # Number of existing points
    p <- ncol(expo)     # Dimension

    # Check dimension consistency
    if (p != ncol(ts)) {
      stop("Dimension of expo must match training samples")
    }

    # Adjust parameters: existing expo as the first slice, need to generate K new slices
    # Total number of slices = K + 1
    total_slices <- K + 1

    # Reinterpret nv: now nv only applies to new slices to be generated
    if (length(nv) == 1) {
      if (nv %% K != 0) {
        stop("If no subset points are specified, nv should be a multiple of K")
      }
      nv <- rep(nv / K, K)
    } else {
      if (length(nv) != K) {
        stop("When expo is provided, length(nv) should equal K (number of new slices)")
      }
    }

    # Create vector of number of points for all slices
    nv_all <- c(nexp, nv)

  } else {
    # Case without existing point sets
    total_slices <- K
    nv_all <- nv
    nexp <- 0

    if (length(nv) == 1) {
      if (K == 1) {
        stop("Please specify the number of slices")
      }
      if (nv %% K != 0) {
        stop("If no subset points are specified, nv should be a multiple of K")
      }
      nv_all <- rep(nv / K, K)
    } else {
      if (length(nv) != K) {
        stop("The number of slices may be wrong")
      }
    }
  }

  # Set number of cores for parallel computation
  if (is.null(n_cores)) {
    n_cores <- max(1, parallel::detectCores() - 1)
  }
  n_cores <- as.integer(n_cores)

  if (n_cores < 1) {
    stop("Number of cores must be at least 1")
  }

  cat(paste("Using", n_cores, "CPU cores for computation\n"))

  # Calculate lambda if not provided
  if (is.null(lambda)) {
    if (!is.null(expo)) {
      # Case with existing point sets: calculate lambda starting from the second slice
      lambda <- rep(1, total_slices)
      nall <- nexp  # Accumulate starting from existing points

      for (k in 2:total_slices) {
        nall <- nall + nv_all[k]
        lambda[k] <- (nall + nv_all[k]) / (2 * nall)  # lambda_k = (nc + nk) / (2 * nc)
      }
      # No lambda needed for the first slice (existing points), set to 0 or NA
      lambda[1] <- 0
    } else {
      # Case without existing point sets: original logic
      lambda <- rep(1, total_slices)
      nall <- nv_all[1]
      for (k in 2:total_slices) {
        nall <- nall + nv_all[k]
        lambda[k] <- (nall + nv_all[k]) / (2 * nall)
      }
    }
  } else {
    if (any(lambda < 0) || any(lambda > 1)) {
      stop("lambda should be in [0,1]")
    }
    if (length(lambda) == 1) {
      lambda <- rep(lambda, total_slices)
    } else if (length(lambda) != total_slices) {
      stop(paste("Length of lambda must be 1 or equal to total slices (", total_slices, ")", sep=""))
    }
  }

  cat("Lambda values:", paste(round(lambda, 3), collapse = ", "), "\n")

  # Initial points
  N <- nrow(ts)
  p <- ncol(ts)

  # Transpose training samples for efficient computation
  trts <- t(ts)
  emojis <- c(
    "\U1F634",
    "\U1F60A",
    "\U1F60E",
    "\U1F680",
    "\U1F389"
  )

  # Process weights parameter
  if (length(weights) == 1) {
    weights_vec <- rep(weights, N)
  } else if (length(weights) != N) {
    stop("Length of weights must be 1 or equal to the number of training samples")
  } else {
    weights_vec <- as.vector(weights)
  }

  # Sort nv (give priority to generating point sets with small sample sizes)
  # Only sort newly generated slices, keep existing point sets unchanged
  if (!is.null(expo)) {
    # First slice is existing point set, no sorting
    # Sort new slices
    nv_sorted <- sort(nv_all[-1])
    nv_all <- c(nv_all[1], nv_sorted)
  } else {
    nv_all <- sort(nv_all)
  }

  # Create slice number vector
  if (!is.null(expo)) {
    # First slice is existing point set
    slicenumber <- c(rep(1, nexp), rep(2:(K+1), times = nv_all[-1]))
  } else {
    slicenumber <- rep(1:K, times = nv_all)
  }

  # Set up parallel backend if using R parallel implementation
  if (use_cpp) {
    # Use C++ implementation
    cat("Using C++ implementation with OpenMP\n")

    # Set OpenMP thread count
    old_threads <- Sys.getenv("OMP_NUM_THREADS")
    Sys.setenv(OMP_NUM_THREADS = n_cores)
    on.exit(Sys.setenv(OMP_NUM_THREADS = old_threads))

    if (!is.null(expo)) {
      result <- seqSlicedRP_complete_cpp(nv_all, total_slices, ts, lambda,
                                         weights_vec, T, n_cores, expo, TRUE)
    } else {
      # Pass empty arma::mat matrix
      empty_mat <- matrix(numeric(0), nrow = 0, ncol = ncol(ts))
      result <- seqSlicedRP_complete_cpp(nv_all, total_slices, ts, lambda,
                                         weights_vec, T, n_cores, empty_mat, TRUE)
    }
    return(result)

  } else if (n_cores > 1) {
    # Use R parallel implementation
    cat("Using R parallel implementation\n")

    # Setup parallel backend
    cl <- parallel::makeCluster(n_cores)
    doParallel::registerDoParallel(cl)
    on.exit(parallel::stopCluster(cl))

    # Initialize existing point set
    if (!is.null(expo)) {
      nc <- nexp         # Current number of points is existing points
      Pnc <- expo        # Current points are existing point set
      start_k <- 2       # Start generating from the second slice
    } else {
      nc <- 0            # Current number of points is 0
      Pnc <- NULL        # Current point set is empty
      start_k <- 1       # Start generating from the first slice
    }

    for (k in start_k:total_slices) {
      # Random initialization for current slice
      Indexinitial <- sample(1:N, nv_all[k], replace = FALSE)
      Pnk <- ts[Indexinitial, ]

      # MM algorithm iteration
      Pnknew <- Pnk

      for (t in 1:T) {
        # Parallel computation using foreach
        Pnknew_list <- foreach::foreach(
          i = 1:nv_all[k],
          .combine = rbind,
          .packages = c()
        ) %dopar% {
          xdy <- Pnk[i, ] - trts
          normxy <- sqrt(colSums(xdy * xdy))
          normxy[normxy == 0] <- 1

          xdxk <- t(Pnk[i, ] - t(Pnk))
          normxxk <- sqrt(rowSums(xdxk * xdxk))
          normxxk[normxxk == 0] <- 1
          xdxk <- xdxk / normxxk

          if (nc != 0) {
            xdxc <- t(Pnk[i, ] - t(Pnc))
            normxxc <- sqrt(rowSums(xdxc * xdxc))
            normxxc[normxxc == 0] <- 1
            xdxc <- xdxc / normxxc
            lambdatr <- lambda[k] * (nc) / (nc + nv_all[k])
          } else {
            xdxc <- matrix(0, 2, 2)
            lambdatr <- 0
          }

          # Update point
          update <- 1 / mean(weights / normxy) *
            (colMeans(ts * weights / normxy) +
               (1 - lambdatr) * colMeans(xdxk) +
               lambdatr * colMeans(xdxc))

          as.numeric(update)
        }

        Pnk <- as.matrix(Pnknew_list)
        progress <- round(t/T * 100)
        emoji_index <- min(ceiling(progress/20), length(emojis))
        cat(sprintf("\r Progress: %3d%% %s", progress, emojis[emoji_index]))
        flush.console()
      }

      # Update accumulated points
      nc <- nc + nv_all[k]
      Pnc <- rbind(Pnc, Pnk)

      cat(sprintf("Slice %d/%d complete\n", k, total_slices))
    }

    return(list(Pn = Pnc, slicenumber = slicenumber))

  } else {
    # Use serial implementation
    cat("Using serial implementation\n")

    # Initialize existing point set
    if (!is.null(expo)) {
      nc <- nexp         # Current number of points is existing points
      Pnc <- expo        # Current points are existing point set
      start_k <- 2       # Start generating from the second slice
    } else {
      nc <- 0            # Current number of points is 0
      Pnc <- NULL        # Current point set is empty
      start_k <- 1       # Start generating from the first slice
    }

    for (k in start_k:total_slices) {
      # Random initialization for current slice
      Indexinitial <- sample(1:N, nv_all[k], replace = FALSE)
      Pnk <- ts[Indexinitial, ]

      # MM algorithm iteration
      for (t in 1:T) {
        Pnknew <- matrix(0, nv_all[k], p)

        for (i in 1:nv_all[k]) {
          xdy <- Pnk[i, ] - trts
          normxy <- sqrt(colSums(xdy * xdy))
          normxy[normxy == 0] <- 1

          xdxk <- t(Pnk[i, ] - t(Pnk))
          normxxk <- sqrt(rowSums(xdxk * xdxk))
          normxxk[normxxk == 0] <- 1
          xdxk <- xdxk / normxxk

          if (nc != 0) {
            xdxc <- t(Pnk[i, ] - t(Pnc))
            normxxc <- sqrt(rowSums(xdxc * xdxc))
            normxxc[normxxc == 0] <- 1
            xdxc <- xdxc / normxxc
            lambdatr <- lambda[k] * (nc) / (nc + nv_all[k])
          } else {
            xdxc <- matrix(0, 2, 2)
            lambdatr <- 0
          }

          # Update point
          Pnknew[i, ] <- 1 / mean(weights / normxy) *
            (colMeans(ts * weights / normxy) +
               (1 - lambdatr) * colMeans(xdxk) +
               lambdatr * colMeans(xdxc))
        }

        Pnk <- Pnknew
        progress <- round(t/T * 100)
        emoji_index <- min(ceiling(progress/20), length(emojis))
        cat(sprintf("\r Progress: %3d%% %s", progress, emojis[emoji_index]))
        flush.console()
      }

      # Update accumulated points
      nc <- nc + nv_all[k]
      Pnc <- rbind(Pnc, Pnk)

      cat(sprintf("Slice %d/%d complete\n", k, total_slices))
    }

    return(list(Pn = Pnc, slicenumber = slicenumber))
  }
}
