#' Sliced Representative Points with Weighted Hybrid Energy Distance Criterion
#'
#' This function implements sliced representative points based on the weighted
#' hybrid energy distance criterion with parallel computation support.
#'
#' @param nv Vector specifying number of points in each slice, or total number of points
#' @param K Number of slices (default: length(nv))
#' @param ts Training sample matrix
#' @param lambda Balanced parameter (default: 0.5)
#' @param weights Vector of weights for training samples (default: 1)
#' @param T Maximum number of iterations (default: 200)
#' @param n_cores Number of CPU cores for parallel computation (default: NULL, uses detectCores() - 1)
#' @param use_cpp Logical, whether to use C++ implementation (default: TRUE)
#'
#' @return List containing:
#'   \item{Pn}{Matrix of representative points}
#'   \item{slicenumber}{Vector indicating slice membership for each point}
#'
#' @examples
#' \dontrun{
#' if (!require("randtoolbox")) install.packages("randtoolbox")
#' # 3 slices with n1=n2=n3=20
#' set.seed(123)
#' # training sample
#' ts <- sobol(100000, 2, scrambling = 3)
#' result0 <- slicedRPParallel(c(20, 20, 20), ts = ts,lambda = 0.5)
#' plot(result0$Pn, col = result0$slicenumber, pch = result0$slicenumber + 15,
#'      cex = 2, xlim = c(0, 1), ylim = c(0, 1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#'
#' # 3 slices with n1=10,n2=20,n3=25
#' result1 <- slicedRPParallel(c(10, 20, 25), ts = ts,lambda = 0.5)
#' plot(result1$Pn, col = result1$slicenumber, pch = result1$slicenumber + 15,
#'      cex = 2, xlim = c(0, 1), ylim = c(0, 1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#'
#' # Generalized (weighted) Sliced Representative Points
#' result2 <- slicedRPParallel(c(20, 20, 20), ts = ts,weights =apply(dbeta(ts,0.5,0.5),1,prod),lambda = 0.5)
#' plot(result2$Pn, col = result2$slicenumber, pch = result2$slicenumber + 15,
#'      cex = 2, xlim = c(0, 1), ylim = c(0, 1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' }
#'
#' @importFrom parallel detectCores makeCluster stopCluster
#' @importFrom foreach foreach %dopar%
#' @importFrom doParallel registerDoParallel
#' @importFrom Rcpp evalCpp sourceCpp
#' @useDynLib RP4design
#' @export
slicedRPParallel <- function(nv, K = length(nv), ts, lambda = 0.5, weights = 1,
                             T = 200, n_cores = NULL, use_cpp = TRUE) {

  # Confirm the number of slices and the number of points in each slice
  if (length(nv) == 1) {
    if (K == 1) {
      stop("Please specify the number of slices")
    }
    if (nv %% K != 0) {
      stop("If no subset points are specified, nv should be a multiple of K")
    }
    nv <- rep(nv / K, K)
  } else {
    if (length(nv) != K) {
      stop("The number of slices may be wrong")
    }
  }

  if (lambda < 0 | lambda > 1) {
    stop("lambda should be in [0,1]")
  }

  # Initial points
  N <- nrow(ts)
  p <- ncol(ts)
  n <- sum(nv)

  # Random initialization of representative points
  Indexinitial <- sample(1:N, n, replace = FALSE)
  Pn <- ts[Indexinitial, ]

  # Create slice number vector
  slicenumber <- rep(1:K, times = nv)  # The slice where each point is located (fixed)

  # Set number of cores for parallel computation
  if (is.null(n_cores)) {
    n_cores <- max(1, parallel::detectCores() - 1)
  }
  n_cores <- as.integer(n_cores)

  if (n_cores < 1) {
    stop("Number of cores must be at least 1")
  }

  cat(paste("Using", n_cores, "CPU cores for computation\n"))

  # Process weights parameter
  if (length(weights) == 1) {
    weights_vec <- rep(weights, N)
  } else if (length(weights) != N) {
    stop("Length of weights must be 1 or equal to the number of training samples")
  } else {
    weights_vec <- as.vector(weights)
  }

  # Transpose training samples for efficient computation
  trts <- t(ts)

  emojis <- c(
    "\U1F634",
    "\U1F60A",
    "\U1F60E",
    "\U1F680",
    "\U1F389"
  )
  # MM algorithm iteration
  if (use_cpp) {
    # Use C++ implementation
    cat("Using C++ implementation with OpenMP\n")

    # Set OpenMP thread count
    old_threads <- Sys.getenv("OMP_NUM_THREADS")
    Sys.setenv(OMP_NUM_THREADS = n_cores)
    on.exit(Sys.setenv(OMP_NUM_THREADS = old_threads))

    for (t in 1:T) {
      # Call C++ function
      Pn <- slicedRP_parallel_cpp(Pn, trts, ts, slicenumber, weights_vec, lambda, n_cores)
      progress <- round(t/T * 100)
      emoji_index <- min(ceiling(progress/20), length(emojis))

      cat(sprintf("\r Progress: %3d%% %s", progress, emojis[emoji_index]))
      flush.console()    }
    cat(sprintf("Iteration %d/%d complete\n", t, T))
  } else if (n_cores > 1) {
    # Use R parallel implementation
    cat("Using R parallel implementation\n")

    # Setup parallel backend
    cl <- parallel::makeCluster(n_cores)
    doParallel::registerDoParallel(cl)
    on.exit(parallel::stopCluster(cl))

    for (t in 1:T) {
      # Parallel computation using foreach
      Pnnew_list <- foreach::foreach(
        i = 1:n,
        .combine = rbind,
        .packages = c()
      ) %dopar% {
        xdy <- Pn[i, ] - trts
        normxy <- sqrt(colSums(xdy * xdy))
        normxy[normxy == 0] <- 1

        xdx <- t(Pn[i, ] - t(Pn))
        normxx <- sqrt(rowSums(xdx * xdx))
        normxx[normxx == 0] <- 1
        xdx <- xdx / normxx

        # Update point with weights
        update <- 1 / mean(weights / normxy) *
          (colMeans(ts * weights / normxy) +
             (1 - lambda) * colMeans(xdx[slicenumber == slicenumber[i], ]) +
             lambda * colMeans(xdx))

        as.numeric(update)
      }

      Pn <- as.matrix(Pnnew_list)
      progress <- round(t/T * 100)
      emoji_index <- min(ceiling(progress/20), length(emojis))

      cat(sprintf("\r Progress: %3d%% %s", progress, emojis[emoji_index]))
      flush.console()    }
    cat(sprintf("Iteration %d/%d complete\n", t, T))
  } else {
    # Use serial implementation
    cat("Using serial implementation\n")

    for (t in 1:T) {
      Pnnew <- matrix(0, n, p)

      for (i in 1:n) {
        xdy <- Pn[i, ] - trts
        normxy <- sqrt(colSums(xdy * xdy))
        normxy[normxy == 0] <- 1

        xdx <- t(Pn[i, ] - t(Pn))
        normxx <- sqrt(rowSums(xdx * xdx))
        normxx[normxx == 0] <- 1
        xdx <- xdx / normxx

        # Update point with weights
        update <- 1 / mean(weights / normxy) *
          (colMeans(ts * weights / normxy) +
             (1 - lambda) * colMeans(xdx[slicenumber == slicenumber[i], ]) +
             lambda * colMeans(xdx))

        Pnnew[i, ] <- update
      }

      Pn <- Pnnew
      progress <- round(t/T * 100)
      emoji_index <- min(ceiling(progress/20), length(emojis))

      cat(sprintf("\r Progress: %3d%% %s", progress, emojis[emoji_index]))
      flush.console()
      cat(sprintf("Iteration %d/%d complete\n", t, T))
    }
  }

  return(list(Pn = Pn, slicenumber = slicenumber))
}
