#' Gibbs sampler for generating general mixture experimental
#' region with linear constraints
#'
#' The C++ implementation provides significant performance improvements.
#'
#' @param a0 Numeric vector of lower bounds (length p)
#' @param b0 Numeric vector of upper bounds (length p)
#' @param n Integer, number of samples to generate
#' @param A Numeric matrix of linear constraints, Ax[,-p]<=lb (optional)
#' @param lb Numeric vector of linear bounds for constraints, Ax<=lb (optional)
#' @param x0 Numeric vector, initial point (optional)
#'
#' @return A list containing:
#'   \item{sample}{Matrix of generated samples (n x p)}
#'   \item{xstar}{Initial sample point}
#'
#' @examples
#' \dontrun{
#' # Mixture experimental region T_3={(x_1,x_2,x_3)|x_i>=0.3,i=1,2,3,x_1+x_2+x_3=1}
#' # Sliced space-filling design with mixtures
#' a <- rep(0,3)
#' b <- rep(1,3)
#' ts <- gibbs_samplerformixture(a,b,n = 105000)$sample[-(1:5000),]
#' result <- slicedRPParallel(c(10, 10, 10), ts = ts,lambda = 0.5)
#' if (!require("vcd")) install.packages("vcd")
#' ternaryplot(result$Pn,col=result$slicenumber+1,pch=result$slicenumber+15,main = "")
#'
#' # Generalized (weighted) Sliced space-filling design with mixtures
#' if(!require("DIRECT")) install.packages("DIRECT")
#' weights0 <- apply(ts,1,function(x){dDirichlet(x,alpha = rep(1/2,3))})
#' weights <- weights0/sum(weights0)*length(weights0)
#' result2 <- slicedRPParallel(c(10, 10, 10), ts = ts,weights = weights,lambda = 0.5)
#' ternaryplot(result2$Pn,col=result2$slicenumber+1,pch=result2$slicenumber+15,main = "")
#'
#' # GSSFD (sequential)
#' result2 <- SeqslicedRP(c(10, 15, 25), ts = ts,weights = weights,lambda = 0.5)
#' ternaryplot(result2$Pn,col=result2$slicenumber+1,pch=result2$slicenumber+15,main = "")
#'
#' # Mixture experimental region T_3={(x_1,x_2,x_3)|x_i>=0,
#' # i=1,2,3,x_1+x_2+x_3=1,x_1+2*x_2<=0.8}
#' tswithlc=gibbs_samplerformixture(rep(0,3),rep(1,3),105000,A = matrix(c(1,2),1,2),lb=0.8)$sample[-c(1:5000),]
#' result3 <- slicedRPParallel(c(10, 10, 10), ts = tswithlc,lambda = 0.5)
#' ternaryplot(result3$Pn,col=result3$slicenumber+1,pch=result3$slicenumber+15,main = "")
#'
#' }
#' @export
gibbs_samplerformixture <- function(a0, b0, n, A = NULL, lb = NULL, x0 = 0) {
  # 输入验证
  if (!is.numeric(a0) || !is.numeric(b0)) {
    stop("a0 and b0 must be numeric vectors")
  }
  if (length(a0) != length(b0)) {
    stop("a0 and b0 must have the same length")
  }
  if (length(a0) < 2) {
    stop("The length of a0 must be at least 2")
  }
  if (n <= 0) {
    stop("n must be positive")
  }

  p <- length(a0)

  # 处理A和lb参数
  A_matrix <- NULL
  lb_vec <- NULL

  if (!is.null(A)) {
    A_matrix <- as.matrix(A)
    if (ncol(A_matrix) != p-1) {
      stop(sprintf("Matrix A must have %d columns (p-1)", p-1))
    }

    if (is.null(lb)) {
      stop("When A is provided, lb must also be provided")
    }

    lb_vec <- as.numeric(lb)
    if (length(lb_vec) != nrow(A_matrix)) {
      stop("lb must have the same length as the number of rows in A")
    }
  }

  # 调用C++函数
  result <- gibbs_sampler_cpp(
    a0 = as.numeric(a0),
    b0 = as.numeric(b0),
    n_ = as.integer(n),
    A_ = A_matrix,
    lb_ = lb_vec,
    x0_ = as.numeric(x0)
  )

  return(result)
}
