#' Calculate Uniformity Criteria (UNICRI)
#'
#' This function calculates five uniformity criteria between a design matrix
#' and a target region. It's a wrapper for the optimized C++ implementation.
#'
#' @param design A numeric matrix representing the experimental design points
#' @param region A numeric matrix representing the large sample from uniform distribution defined on target region
#' @return A data frame with five criteria:
#'   \item{mu}{Distance between means}
#'   \item{sd}{Distance between standard deviations}
#'   \item{RMSD}{Root mean square distance}
#'   \item{MaD}{Maximum packing distance}
#'   \item{MiD}{Minimum separation distance}
#' @export
#' @examples
#' design <- matrix(rnorm(30), ncol = 3)
#' region <- matrix(rnorm(60), ncol = 3)
#' unicri(design, region)
unicri <- function(design, region) {
  # Input validation
  if (!is.matrix(design) || !is.matrix(region)) {
    stop("Both design and region must be matrices")
  }
  if (ncol(design) != ncol(region)) {
    stop("Design and region must have the same number of columns")
  }

  # Call the C++ implementation
  result <- unicri_cpp(design, region)

  return(result)
}
