#' $w$-way coupled representative points based on Hybrid energy distance criterion
#'
#' This function implements the weighted representative points algorithm
#' for experimental design with qualitative variables with optimized parallel computing.
#'
#' @param Pz Design of $q$ qualitative variables, q<=2, otherwise use the function for Sliced representative points directly
#' @param ts Matrix of training samples (quantitative variables)
#' @param w The largest number of qualitative variables to consider
#' @param lambda Balanced parameter belongs to [0,1]
#' @param avetheta Logical, whether to use average theta
#' @param weights Vector of weights if importance sampling methods is used
#' @param T Number of iterations
#' @param n_cores Number of CPU cores to use for parallel computation
#' @param use_cpp Logical, whether to use C++ implementation
#' @param chunk_size Size of chunks for parallel processing (default: auto-calculated)
#'
#' @return Matrix of representative points
#' @examples
#' \dontrun{
#' # Example usage
#' if (!require("randtoolbox")) install.packages("randtoolbox")
#' if (!require("DoE.base")) install.packages("DoE.base")
#' # 3 factors 2 levels
#' base_design <- fac.design(
#'  nfactors = 3,
#'  nlevels = c(2,2,2),
#'  replications = 5,
#'  randomize = FALSE
#'  )
#' Pz0=data.matrix(base_design)
#' # design of qualitative variables
#' Pz = Pz0[,-4]
#' # training sample
#' ts=sobol(100000,2,scrambling = 3)
#'
#' D3new=wwCRPParallel(Pz,w = 3,ts=ts,lambda =0.5,
#' avetheta = F,T = 300)
#' plot(D3new,col=data.matrix(classify_rows(Pz))
#' ,pch=data.matrix(classify_rows(Pz))+10,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' plot(D3new,col=data.matrix(classify_rows(Pz,1:2))
#' ,pch=data.matrix(classify_rows(Pz[,1:2]))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' plot(D3new,col=data.matrix(classify_rows(Pz,c(1,3)))
#' ,pch=data.matrix(classify_rows(Pz[,c(1,3)]))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' plot(D3new,col=data.matrix(classify_rows(Pz,2:3)),
#' pch=data.matrix(classify_rows(Pz[,2:3]))+13,
#' cex=2,xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")

#' # Douly coupled design
#' D2new=wwCRPParallel(Pz,w = 2,ts=ts,
#' lambda =0.5,avetheta = F,T = 300)
#' plot(D2new,col=data.matrix(classify_rows(Pz,1:2))
#' ,pch=data.matrix(classify_rows(Pz,1:2))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' plot(D2new,col=data.matrix(classify_rows(Pz,c(1,3)))
#' ,pch=data.matrix(classify_rows(Pz,c(1,3)))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' plot(D2new,col=data.matrix(classify_rows(Pz,2:3))
#' ,pch=data.matrix(classify_rows(Pz,2:3))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#'
#' # Marginally couple desgin
#' D1new=wwCRPParallel(Pz,w =1,ts=sobol(100000,2,scrambling = 3),lambda =0.5,avetheta = F,T = 300)
#' for(i in 1:3)
#' {
#'   plot(D1new,col=classify_rows(Pz,i),
#'   pch=classify_rows(Pz,i)+15,cex=2,xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' }
#' # Generalized Douly coupled design
#' D2new=wwCRPParallel(Pz,w = 2,ts=ts,
#' weights = apply(dbeta(ts,0.5,0.5),1,prod),
#' lambda =0.5,avetheta = F,T = 300)
#'
#' plot(D2new,col=data.matrix(classify_rows(Pz,1:2)),
#' pch=data.matrix(classify_rows(Pz,1:2))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' plot(D2new,col=data.matrix(classify_rows(Pz,c(1,3))),
#' pch=data.matrix(classify_rows(Pz,c(1,3)))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' plot(D2new,col=data.matrix(classify_rows(Pz,2:3)),
#' pch=data.matrix(classify_rows(Pz,2:3))+13,cex=2,
#' xlim=c(0,1),ylim=c(0,1),xaxs = "i", yaxs ="i",xlab = "",ylab="")
#' }
#'
#' @importFrom parallel detectCores makeCluster stopCluster clusterExport
#' @importFrom foreach foreach %dopar%
#' @importFrom doParallel registerDoParallel
#' @importFrom Rcpp evalCpp sourceCpp
#' @useDynLib RP4design
#' @export
wwCRPParallel <- function(Pz, ts, w = 1, lambda = 0.5, avetheta = FALSE,
                          weights = 1, T = 300, n_cores = NULL,
                          use_cpp = TRUE, chunk_size = NULL) {

  # Validate inputs
  if (!is.matrix(Pz) && !is.data.frame(Pz)) {
    stop("Pz must be a matrix or data frame")
  }
  if (!is.matrix(ts) && !is.data.frame(ts)) {
    stop("ts must be a matrix or data frame")
  }

  # Convert to matrix if data frame
  Pz <- as.matrix(Pz)
  ts <- as.matrix(ts)

  # Check dimensions
  n <- nrow(Pz)   # Total number of representative points
  q <- ncol(Pz)   # Number of qualitative variables
  N <- nrow(ts)   # Number of points in training sample
  p <- ncol(ts)   # Number of quantitative variables

  # Validation checks
  if (q == 1) {
    stop("Please use slicedRP function when there is only one qualitative variable")
  }
  if (w == q && q >= 2) {
    warning("Note that wwCRP with w=q (q>=2) is different from SlicedRP!")
  }

  # Process weights parameter
  if (length(weights) == 1) {
    weights <- rep(weights, N)
  } else if (length(weights) != N) {
    stop("Length of weights must be 1 or equal to the number of training samples")
  }

  # Set number of cores for parallel computation
  if (is.null(n_cores)) {
    n_cores <- max(1, parallel::detectCores() - 1)
  }
  n_cores <- as.integer(n_cores)

  if (n_cores < 1) {
    stop("Number of cores must be at least 1")
  }

  # Set chunk size if not provided
  if (is.null(chunk_size)) {
    # Calculate optimal chunk size based on problem size
    chunk_size <- max(32, ceiling(n / (n_cores * 4)))
  }

  cat(paste("Using", n_cores, "CPU cores with chunk size", chunk_size, "\n"))

  # Optimized helper function to find index list for all w combinations
  findindexallw_optimized <- function(Pz, w) {
    n <- nrow(Pz)
    q <- ncol(Pz)

    if (w < 1 || w > q) {
      stop("w must be between 1 and the number of columns of Pz")
    }

    # Pre-allocate result list
    result_list <- vector("list", n)
    mapped_id_counter <- 1

    # Process each l from 1 to w
    for (l in 1:w) {
      # Generate all column combinations
      comb_list <- combn(q, l, simplify = FALSE)

      # Process each column combination
      for (cols in comb_list) {
        sub_mat <- Pz[, cols, drop = FALSE]

        # Convert rows to strings for comparison
        row_strings <- apply(sub_mat, 1, function(x) paste(x, collapse = "\r"))

        # Use factor to find all identical rows
        row_factor <- as.integer(factor(row_strings, levels = unique(row_strings)))

        # Find all row indices for each factor value
        for (factor_val in unique(row_factor)) {
          identical_rows <- which(row_factor == factor_val)

          # Create matrix for new entries
          new_entries <- cbind(identical_rows,
                               rep(mapped_id_counter, length(identical_rows)))
          colnames(new_entries) <- c("row_index", "mapped_id")

          # Add to result list for each identical row
          for (row_idx in identical_rows) {
            if (is.null(result_list[[row_idx]])) {
              result_list[[row_idx]] <- new_entries
            } else {
              result_list[[row_idx]] <- rbind(result_list[[row_idx]], new_entries)
            }
          }
        }

        # Increment ID after processing current combination
        mapped_id_counter <- mapped_id_counter + 1
      }
    }

    return(result_list)
  }

  # Optimized helper function to calculate distinct combinations
  clcvallw_optimized <- function(matrix_data, w) {
    if (!is.matrix(matrix_data) && !is.data.frame(matrix_data)) {
      stop("Input must be a matrix or data frame")
    }

    if (w > ncol(matrix_data)) {
      stop("w cannot be greater than the number of columns of the matrix")
    }

    n_cols <- ncol(matrix_data)

    # Pre-allocate result list
    result_list <- list()

    # Process each l from 1 to w
    for (l in 1:w) {
      # Get all possible combinations of l columns
      col_combinations <- combn(n_cols, l, simplify = FALSE)

      # Pre-allocate vectors for results
      distinct_counts <- numeric(length(col_combinations))
      l_values <- rep(l, length(col_combinations))

      # Process each column combination
      for (i in seq_along(col_combinations)) {
        cols <- col_combinations[[i]]

        # Extract selected columns
        selected_cols <- matrix_data[, cols, drop = FALSE]

        # Convert each row to a string
        combinations <- apply(selected_cols, 1, function(row) {
          paste(row, collapse = "-")
        })

        # Calculate number of distinct combinations
        distinct_counts[i] <- length(unique(combinations))
      }

      # Store results
      result_list[[l]] <- data.frame(
        distinct_count = distinct_counts,
        l_value = l_values,
        stringsAsFactors = FALSE
      )
    }

    # Combine all results
    result_df <- do.call(rbind, result_list)
    rownames(result_df) <- NULL

    return(result_df)
  }

  # Get index list and calculate lcv
  Indexlist <- findindexallw_optimized(Pz, w)
  lcv <- clcvallw_optimized(Pz, w)

  # Calculate theta
  if (avetheta) {
    theta <- 1 / sum(choose(q, 1:w))
  } else {
    theta <- lcv[, 1] / sum(lcv[, 1])
  }

  # Initialize representative points
  Pn <- ts[sample(1:N, n, replace = FALSE), ]

  # Pre-compute transposed training samples
  trts <- t(ts)

  # Prepare weights and theta as vectors for C++ function
  if (length(weights) == 1) {
    weights_vec <- rep(weights, N)
  } else {
    weights_vec <- as.vector(weights)
  }

  if (length(theta) == 1) {
    theta_vec <- rep(theta, nrow(lcv))
  } else {
    theta_vec <- as.vector(theta)
  }

  # Progress indicators
  emojis <- c(
    "\U1F634",
    "\U1F60A",
    "\U1F60E",
    "\U1F680",
    "\U1F389"
  )

  # Clean Indexlist for C++ usage
  Indexlist_clean <- lapply(Indexlist, function(x) {
    if (is.null(x) || nrow(x) == 0) {
      return(matrix(0, nrow = 0, ncol = 2))
    }
    matrix(as.integer(x), ncol = 2)
  })

  # MM algorithm iteration
  if (use_cpp) {
    # Use C++ implementation with optimizations
    cat("Using optimized C++ implementation\n")

    # Call C++ function with additional parameters
    for (t in 1:T) {
      tryCatch({
        Pn <- wwCRP_parallel_cpp(Pn, trts, ts, weights_vec, lambda,
                                 theta_vec, Indexlist_clean, n_cores, chunk_size)

        progress <- round(t/T * 100)
        emoji_index <- min(ceiling(progress/20), length(emojis))

        cat(sprintf("\rProgress: %3d%% %s", progress, emojis[emoji_index]))
        flush.console()

      }, error = function(e) {
        cat(sprintf("\nError at iteration %d: %s\n", t, e$message))
        return(Pn)
      })
    }

  } else if (n_cores > 1) {
    # Use R parallel implementation with optimizations
    cat("Using optimized R parallel implementation\n")

    # Setup parallel backend with optimized settings
    cl <- parallel::makeCluster(n_cores)
    doParallel::registerDoParallel(cl)

    # Ensure cleanup
    on.exit({
      parallel::stopCluster(cl)
    })

    # Export necessary variables to all workers
    parallel::clusterExport(cl, varlist = c("trts", "ts", "weights",
                                            "lambda", "theta", "Indexlist",
                                            "n", "p", "N"),
                            envir = environment())

    # Create chunks for parallel processing
    chunks <- split(1:n, ceiling(seq_along(1:n) / chunk_size))

    for (t in 1:T) {
      # Process chunks in parallel
      Pnnew_list <- foreach::foreach(
        chunk = chunks,
        .combine = rbind,
        .packages = c(),
        .inorder = TRUE,
        .multicombine = TRUE
      ) %dopar% {
        # Local result matrix for this chunk
        chunk_result <- matrix(0, nrow = length(chunk), ncol = p)

        for (idx in 1:length(chunk)) {
          i <- chunk[idx]

          # Compute distances to training samples
          xdy <- Pn[i, ] - trts
          normxy <- sqrt(colSums(xdy * xdy)) / weights
          normxy[normxy == 0] <- 1

          # Compute distances to other representative points
          xdx <- t(Pn[i, ] - t(Pn))
          normxx <- sqrt(rowSums(xdx * xdx))
          normxx[normxx == 0] <- 1
          xdx <- xdx / normxx

          # Process groups within subdesigns
          idx_mat <- Indexlist[[i]]
          if (!is.null(idx_mat) && nrow(idx_mat) > 0) {
            group_indices <- split(idx_mat[, 1], idx_mat[, 2])

            # Compute mean for each group
            submean <- t(sapply(group_indices, function(rows) {
              colMeans(xdx[rows, , drop = FALSE])
            }))

            # Update point
            update <- 1 / mean(1 / normxy) *
              (colMeans(ts / normxy) +
                 (1 - lambda) * colSums(theta * submean) +
                 lambda * colMeans(xdx))
          } else {
            # No groups found
            update <- 1 / mean(1 / normxy) *
              (colMeans(ts / normxy) +
                 lambda * colMeans(xdx))
          }

          chunk_result[idx, ] <- update
        }

        chunk_result
      }

      Pn <- as.matrix(Pnnew_list)

      # Progress indicator
      progress <- round(t/T * 100)
      emoji_index <- min(ceiling(progress/20), length(emojis))
      cat(sprintf("\rProgress: %3d%% %s", progress, emojis[emoji_index]))
      flush.console()
    }

  } else {
    # Serial implementation with vectorization improvements
    cat("Using optimized serial implementation\n")

    # Pre-allocate matrices for better performance
    Pnnew <- matrix(0, n, p)

    for (t in 1:T) {
      for (i in 1:n) {
        # Vectorized distance computation
        diff_ts <- sweep(ts, 2, Pn[i, ], "-")
        normxy <- sqrt(rowSums(diff_ts^2)) / weights
        normxy[normxy == 0] <- 1

        diff_pn <- sweep(Pn, 2, Pn[i, ], "-")
        normxx <- sqrt(rowSums(diff_pn^2))
        normxx[normxx == 0] <- 1
        xdx <- diff_pn / normxx

        # Process groups
        idx_mat <- Indexlist[[i]]
        if (!is.null(idx_mat) && nrow(idx_mat) > 0) {
          group_indices <- split(idx_mat[, 1], idx_mat[, 2])

          # Compute mean for each group
          submean <- t(sapply(group_indices, function(rows) {
            colMeans(xdx[rows, , drop = FALSE])
          }))

          # Update point
          Pnnew[i, ] <- 1 / mean(1 / normxy) *
            (colSums(ts / normxy) / N +
               (1 - lambda) * colSums(theta * submean) +
               lambda * colSums(xdx) / n)
        } else {
          # No groups found
          Pnnew[i, ] <- 1 / mean(1 / normxy) *
            (colSums(ts / normxy) / N +
               lambda * colSums(xdx) / n)
        }
      }

      Pn <- Pnnew

      # Progress indicator
      progress <- round(t/T * 100)
      emoji_index <- min(ceiling(progress/20), length(emojis))
      cat(sprintf("\rProgress: %3d%% %s", progress, emojis[emoji_index]))
      flush.console()
    }
  }

  cat("\n")  # New line after progress bar
  return(Pn)
}
