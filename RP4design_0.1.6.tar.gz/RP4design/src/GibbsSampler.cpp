#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace arma;
using namespace Rcpp;

class GibbsSampler {
private:
  vec a0, b0, lb, astar, bstar;
  mat A;
  int p, n;
  bool has_constraints;

  // 无约束情况下的边界计算
  vec udf1(int k, const vec& x) {
    double sum_x = sum(x);
    double lower = std::max(astar(k), 1.0 - sum_x - bstar(p-1) + x(k));
    double upper = std::min(bstar(k), 1.0 - sum_x - astar(p-1) + x(k));
    return vec({lower, upper});
  }

  // 有约束情况下的边界计算
  vec udf2(int k, const vec& x) {
    double sum_x = sum(x);
    double lower = std::max(astar(k), 1.0 - sum_x - bstar(p-1) + x(k));
    double upper = std::min(bstar(k), 1.0 - sum_x - astar(p-1) + x(k));

    // 线性约束的边界
    for (int i = 0; i < A.n_rows; ++i) {
      double sum_constraint = 0;
      for (int j = 0; j < p-1; ++j) {
        sum_constraint += A(i, j) * x(j);
      }

      if (A(i, k) > 0) {
        double bound = (lb(i) - sum_constraint + A(i, k) * x(k)) / A(i, k);
        upper = std::min(upper, bound);
      } else if (A(i, k) < 0) {
        double bound = (lb(i) - sum_constraint + A(i, k) * x(k)) / A(i, k);
        lower = std::max(lower, bound);
      }
    }

    return vec({lower, upper});
  }

public:
  GibbsSampler(const vec& a0_, const vec& b0_, int n_,
               const mat& A_ = mat(), const vec& lb_ = vec())
    : a0(a0_), b0(b0_), n(n_) {

    p = a0.n_elem;

    if (p < 2) {
      stop("p must be at least 2");
    }

    double sum_a = sum(a0);
    double sum_b = sum(b0);

    if (sum_b <= 1.0 || sum_a >= 1.0) {
      stop("it is necessary that sum(a)<1 and sum(b)>1");
    }

    astar = zeros<vec>(p);
    bstar = ones<vec>(p);

    for (int i = 0; i < p; ++i) {
      astar(i) = std::max(a0(i), 1.0 - sum_b + b0(i));
      bstar(i) = std::min(b0(i), 1.0 - sum_a + a0(i));
    }

    // 处理约束
    has_constraints = (A_.n_rows > 0 && A_.n_cols > 0);
    if (has_constraints) {
      if (A_.n_cols != p-1) {
        stop("Matrix A must have p-1 columns, where p is the length of a0");
      }
      A = A_;
      if (lb_.n_elem != A.n_rows) {
        stop("lb must have the same length as the number of rows in A");
      }
      lb = lb_;
    }
  }

  List sample(const vec& x0_) {
    mat samples = zeros<mat>(n, p);

    // 初始化x (只使用前p-1个维度)
    vec x = zeros<vec>(p-1);

    // 处理初始点
    if (x0_.n_elem == 1 && x0_(0) == 0) {
      // 默认情况：生成人工初始点
      x = astar.subvec(0, p-2);
      double sum_x = sum(x);

      if (sum_x < (1.0 - bstar(p-1))) {
        vec dstar = bstar.subvec(0, p-2) - astar.subvec(0, p-2);
        double u = R::runif(0, 1);
        x = x + (1.0 - bstar(p-1) - sum_x + u * (bstar(p-1) - astar(p-1))) *
          dstar / sum(dstar);
      }
    } else if (x0_.n_elem == p-1) {
      // 提供了正确的初始点
      x = x0_.subvec(0, p-2);
    } else if (x0_.n_elem == p) {
      // 提供了完整的初始点，提取前p-1个
      x = x0_.subvec(0, p-2);
    } else {
      stop("x0 must have length p-1 or p");
    }

    // 计算第p个分量
    vec current_sample = zeros<vec>(p);
    current_sample.subvec(0, p-2) = x;
    current_sample(p-1) = 1.0 - sum(x);
    samples.row(0) = current_sample.t();

    // Gibbs采样
    uvec indices = linspace<uvec>(0, p-2, p-1);

    for (int m = 1; m < n; ++m) {
      // 随机排列
      indices = shuffle(indices);

      for (int idx = 0; idx < p-1; ++idx) {
        int k = indices(idx);
        vec bounds;

        if (has_constraints) {
          bounds = udf2(k, x);
        } else {
          bounds = udf1(k, x);
        }

        // 确保边界有效
        if (bounds(0) >= bounds(1)) {
          bounds(0) = x(k);
          bounds(1) = x(k) + 1e-10;
        }

        double new_val = R::runif(bounds(0), bounds(1));
        samples(m, k) = new_val;
        x(k) = new_val;
      }

      // 计算第p个分量
      samples(m, p-1) = 1.0 - sum(x);
    }

    return List::create(
      Named("sample") = samples,
      Named("xstar") = samples.row(0)
    );
  }
};

// [[Rcpp::export]]
List gibbs_sampler_cpp(NumericVector a0_, NumericVector b0_, int n_,
                       Nullable<NumericMatrix> A_ = R_NilValue,
                       Nullable<NumericVector> lb_ = R_NilValue,
                       NumericVector x0_ = NumericVector()) {

  // 转换R对象为Armadillo对象
  vec a0 = as<vec>(a0_);
  vec b0 = as<vec>(b0_);
  int n = n_;
  int p = a0.n_elem;

  // 处理A参数
  mat A;
  bool has_constraints = false;

  if (A_.isNotNull()) {
    NumericMatrix A_temp(A_);
    if (A_temp.nrow() > 0 && A_temp.ncol() > 0) {
      A = as<mat>(A_temp);
      if (A.n_cols != p-1) {
        stop("Matrix A must have p-1 columns, where p is the length of a0");
      }
      has_constraints = true;
    }
  }

  // 处理lb参数
  vec lb;
  if (has_constraints) {
    if (lb_.isNotNull()) {
      NumericVector lb_temp(lb_);
      lb = as<vec>(lb_temp);
      if (lb.n_elem != A.n_rows) {
        stop("lb must have the same length as the number of rows in A");
      }
    } else {
      stop("When A is provided, lb must also be provided");
    }
  }

  // 处理默认的x0
  vec x0;
  if (x0_.length() == 0) {
    x0 = zeros<vec>(1);
  } else {
    x0 = as<vec>(x0_);
  }

  // 创建采样器并运行
  GibbsSampler sampler(a0, b0, n, A, lb);
  return sampler.sample(x0);
}

// [[Rcpp::export]]
List gibbs_sampler_for_mixture(NumericVector a0, NumericVector b0, int n,
                               NumericVector x0 = NumericVector()) {
  // 专门为混合模型优化的版本，没有额外的线性约束
  return gibbs_sampler_cpp(a0, b0, n, R_NilValue, R_NilValue, x0);
}
