#include <RcppArmadillo.h>
#include <omp.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;

// [[Rcpp::export]]
arma::mat nested_rpew_core(const arma::mat& Pn, const arma::mat& trts,
                           const arma::uvec& z, const arma::vec& nv,
                           const arma::vec& wv, const arma::vec& weights,int K, int nthreads = 1) {
  int n = Pn.n_rows;
  int p = Pn.n_cols;
  int N = trts.n_cols;
// Validate weights dimension
  if (weights.n_elem != N) {
    Rcpp::stop("Length of weights must equal number of training samples");
  }

  omp_set_num_threads(nthreads);
  mat Pnnew(n, p);

#pragma omp parallel for
  for (int i = 0; i < n; i++) {
    // Calculate xdy and normxy
    rowvec point_i = Pn.row(i);
    mat xdy(p, N);
    for (int j = 0; j < N; j++) {
      xdy.col(j) = point_i.t() - trts.col(j);
    }

    rowvec normxy(N);
    for (int j = 0; j < N; j++) {
      normxy(j) = norm(xdy.col(j), 2);
      if (normxy(j) == 0) normxy(j) = 1;
    }

    // Calculate xdx and normxx
    mat xdx(n, p);
    for (int j = 0; j < n; j++) {
      xdx.row(j) = point_i - Pn.row(j);
    }

    rowvec normxx(n);
    for (int j = 0; j < n; j++) {
      normxx(j) = norm(xdx.row(j), 2);
      if (normxx(j) == 0) normxx(j) = 1;
    }

    // Normalize xdx
    for (int j = 0; j < n; j++) {
      xdx.row(j) = xdx.row(j) / normxx(j);
    }

    // Calculate cumulative row sums
    mat cum_row_sums = cumsum(xdx, 0);

    // Calculate total_avg
    rowvec total_avg(p, fill::zeros);
    double wiv_sum = 0;

    // Calculate sum of weights for layers from z[i] to K
    for (int k = z(i)-1; k < K; k++) {
      wiv_sum += wv(k);
    }

    // Calculate weighted average
    for (int k = z(i)-1; k < K; k++) {
      int n_i = nv(k);
      double weight = wv(k) / wiv_sum;
      total_avg += weight * cum_row_sums.row(n_i-1) / n_i;
    }

    // Calculate colMeans(ts/normxy)
    rowvec ts_normxy_mean(p, fill::zeros);
    for (int j = 0; j < N; j++) {
      ts_normxy_mean += trts.col(j).t()*weights(j) / normxy(j);
    }
    ts_normxy_mean /= N;

    // Calculate mean of 1/normxy
    double mean_inv_normxy = 0;
    for (int j = 0; j < N; j++) {
      mean_inv_normxy += weights(j) / normxy(j);
    }
    mean_inv_normxy /= N;

    // Update point
    Pnnew.row(i) = (ts_normxy_mean + total_avg) / mean_inv_normxy;
  }

  return Pnnew;
}


