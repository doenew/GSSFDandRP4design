#include <RcppArmadillo.h>
#include <vector>
#include <cmath>
#include <algorithm>

// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

// Helper function to compute the update for a single slice point
void compute_slice_point_update(int i, const rowvec& pn_row, const mat& Pnk,
                                const mat& Pnc, const mat& trts, const mat& ts,
                                const vec& weights, double lambda_k,
                                int nc, double& lambdatr, rowvec& update) {

  int nk = Pnk.n_rows;    // Number of points in current slice
  int p = Pnk.n_cols;    // Number of quantitative variables
  int N = ts.n_rows;     // Number of training samples

  // ============ Compute xdy and normxy ============
  mat xdy(p, N);
  for (int j = 0; j < N; j++) {
    for (int k = 0; k < p; k++) {
      xdy(k, j) = pn_row(k) - trts(k, j);
    }
  }

  // Compute normxy = sqrt(colSums(xdy * xdy))
  vec normxy(N);
  for (int j = 0; j < N; j++) {
    double sum_sq = 0.0;
    for (int k = 0; k < p; k++) {
      double val = xdy(k, j);
      sum_sq += val * val;
    }
    double norm_val = sqrt(sum_sq);
    normxy(j) = (norm_val < 1e-14) ? 1.0 : norm_val;
  }

  // ============ Compute xdxk and normxxk ============
  mat xdxk(nk, p);
  for (int j = 0; j < nk; j++) {
    for (int k = 0; k < p; k++) {
      xdxk(j, k) = pn_row(k) - Pnk(j, k);
    }
  }

  // Compute normxxk = sqrt(rowSums(xdxk * xdxk))
  vec normxxk(nk);
  for (int j = 0; j < nk; j++) {
    double sum_sq = 0.0;
    for (int k = 0; k < p; k++) {
      double val = xdxk(j, k);
      sum_sq += val * val;
    }
    double norm_val = sqrt(sum_sq);
    normxxk(j) = (norm_val < 1e-14) ? 1.0 : norm_val;
  }

  // Normalize xdxk = xdxk / normxxk
  for (int j = 0; j < nk; j++) {
    double inv_norm = 1.0 / normxxk(j);
    for (int k = 0; k < p; k++) {
      xdxk(j, k) *= inv_norm;
    }
  }

  // ============ Compute xdxc and normxxc (if nc != 0) ============
  mat xdxc;
  if (nc > 0) {
    // xdxc = t(Pnk[i,] - t(Pnc))
    xdxc.set_size(nc, p);
    for (int j = 0; j < nc; j++) {
      for (int k = 0; k < p; k++) {
        xdxc(j, k) = pn_row(k) - Pnc(j, k);
      }
    }

    // Compute normxxc = sqrt(rowSums(xdxc * xdxc))
    vec normxxc(nc);
    for (int j = 0; j < nc; j++) {
      double sum_sq = 0.0;
      for (int k = 0; k < p; k++) {
        double val = xdxc(j, k);
        sum_sq += val * val;
      }
      double norm_val = sqrt(sum_sq);
      normxxc(j) = (norm_val < 1e-14) ? 1.0 : norm_val;
    }

    // Normalize xdxc = xdxc / normxxc
    for (int j = 0; j < nc; j++) {
      double inv_norm = 1.0 / normxxc(j);
      for (int k = 0; k < p; k++) {
        xdxc(j, k) *= inv_norm;
      }
    }

    // Compute lambdatr = lambda_k * (nc) / (nc + nk)
    lambdatr = lambda_k * nc / (nc + nk);
  } else {
    // If nc == 0, create dummy matrix and set lambdatr to 0
    xdxc.set_size(2, 2);
    xdxc.zeros();
    lambdatr = 0.0;
  }

  // ============ Compute update point ============
  // Compute mean(weights / normxy)
  double mean_weights_normxy = 0.0;
  for (int j = 0; j < N; j++) {
    mean_weights_normxy += weights(j) / normxy(j);
  }
  mean_weights_normxy /= N;

  // Avoid division by zero
  if (mean_weights_normxy < 1e-14) {
    mean_weights_normxy = 1.0;
  }

  // Compute colMeans(ts * weights / normxy)
  rowvec ts_weights_normxy_mean(p, fill::zeros);
  for (int j = 0; j < N; j++) {
    double weight_norm = weights(j) / normxy(j);
    for (int k = 0; k < p; k++) {
      ts_weights_normxy_mean(k) += ts(j, k) * weight_norm;
    }
  }
  ts_weights_normxy_mean /= N;

  // Compute colMeans(xdxk)
  rowvec xdxk_mean(p, fill::zeros);
  for (int j = 0; j < nk; j++) {
    for (int k = 0; k < p; k++) {
      xdxk_mean(k) += xdxk(j, k);
    }
  }
  xdxk_mean /= nk;

  // Compute colMeans(xdxc) if nc > 0
  rowvec xdxc_mean(p, fill::zeros);
  if (nc > 0) {
    for (int j = 0; j < nc; j++) {
      for (int k = 0; k < p; k++) {
        xdxc_mean(k) += xdxc(j, k);
      }
    }
    xdxc_mean /= nc;
  }

  // Final update formula:
  // update = 1/mean(weights/normxy) * (colMeans(ts*weights/normxy) +
  //          (1-lambdatr)*colMeans(xdxk) + lambdatr*colMeans(xdxc))
  double inv_mean_weights_normxy = 1.0 / mean_weights_normxy;

  for (int k = 0; k < p; k++) {
    update(k) = inv_mean_weights_normxy *
      (ts_weights_normxy_mean(k) +
      (1.0 - lambdatr) * xdxk_mean(k) +
      lambdatr * xdxc_mean(k));
  }
}

// Main function for sequential sliced RP parallel computation
// [[Rcpp::export]]
arma::mat seqSlicedRP_parallel_cpp(const arma::mat& Pnk, const arma::mat& Pnc,
                                   const arma::mat& trts, const arma::mat& ts,
                                   const arma::vec& weights, double lambda_k,
                                   int T, int n_cores) {

  int nk = Pnk.n_rows;    // Number of points in current slice
  int p = Pnk.n_cols;     // Number of quantitative variables
  int nc = Pnc.n_rows;    // Number of current points (may be 0)

  // Initialize matrices for iteration
  mat Pnk_current = Pnk;
  mat Pnk_new(nk, p, fill::zeros);

  // Perform T iterations
  for (int t = 0; t < T; t++) {
    // Parallel computation using OpenMP
#pragma omp parallel for num_threads(n_cores)
    for (int i = 0; i < nk; i++) {
      rowvec pn_row = Pnk_current.row(i);
      rowvec update(p);
      double lambdatr;

      // Compute update for this point
      compute_slice_point_update(i, pn_row, Pnk_current, Pnc, trts, ts,
                                 weights, lambda_k, nc, lambdatr, update);

      // Store result
      for (int k = 0; k < p; k++) {
        Pnk_new(i, k) = update(k);
      }
    }

    // Update current matrix for next iteration
    Pnk_current = Pnk_new;
  }

  return Pnk_current;
}

// Alternative function: process all slices sequentially with C++ (for complete replacement)
// [[Rcpp::export]]
Rcpp::List seqSlicedRP_complete_cpp(const arma::ivec& nv_all, int total_slices,
                                    const arma::mat& ts, const arma::vec& lambda,
                                    const arma::vec& weights, int T, int n_cores,
                                    const arma::mat& expo = arma::mat(),
                                    bool ifparallel = true) {

  int N = (int)ts.n_rows;     // Number of training samples
  int p = (int)ts.n_cols;     // Number of quantitative variables

  // Validate weights dimension
  if ((int)weights.n_elem != N) {
    Rcpp::stop("Length of weights must equal number of training samples");
  }

  // Check if expo is provided
  bool has_expo = (expo.n_rows > 0 && expo.n_cols > 0);

  // Calculate total number of points
  int total_points = (int)sum(nv_all);
  ivec slicenumber(total_points);

  // Create slice number vector
  int idx = 0;
  if (has_expo) {
    // First slice is existing point set
    for (uword i = 0; i < (uword)nv_all(0); i++) {
      slicenumber(idx++) = 1;
    }
    // Newly generated slices are numbered starting from 2
    for (int k = 1; k < total_slices; k++) {
      for (uword i = 0; i < (uword)nv_all(k); i++) {
        slicenumber(idx++) = k + 1;
      }
    }
  } else {
    // Case without existing point set
    for (int k = 0; k < total_slices; k++) {
      for (uword i = 0; i < (uword)nv_all(k); i++) {
        slicenumber(idx++) = k + 1;
      }
    }
  }

  // Transpose training samples for efficient computation
  mat trts = ts.t();

  // Initialize current points matrix
  mat Pnc;
  int nc = 0;  // Number of current points

  // Process existing point set
  if (has_expo) {
    if ((int)expo.n_cols != p) {
      Rcpp::stop("Dimension of expo must match training samples");
    }
    Pnc = expo;
    nc = (int)expo.n_rows;

    Rcpp::Rcout << "Existing points (slice 1) loaded: " << nc << " points" << std::endl;
  }

  // Determine starting slice
  int start_k = has_expo ? 1 : 0;

  // Sort slices to be generated (prioritize slices with fewer points)
  // Note: Existing point set is not included in sorting
  ivec nv_to_generate = nv_all.subvec(start_k, total_slices - 1);
  uvec nv_sorted_indices = sort_index(nv_to_generate);

  // Reorder slices to be generated
  ivec nv_ordered(total_slices);
  uvec lambda_ordered(total_slices);

  if (has_expo) {
    // Keep first slice unchanged
    nv_ordered(0) = nv_all(0);
    lambda_ordered(0) = 0;  // No lambda needed for first slice
  }

  for (uword i = 0; i < nv_sorted_indices.n_elem; i++) {
    int sorted_idx = (int)nv_sorted_indices(i);
    nv_ordered(start_k + (int)i) = nv_to_generate(sorted_idx);
    lambda_ordered(start_k + (int)i) = start_k + sorted_idx;
  }

  // Main loop over slices to generate
  for (uword gen_idx = 0; gen_idx < nv_sorted_indices.n_elem; gen_idx++) {
    int original_k = (int)lambda_ordered(start_k + (int)gen_idx);  // Original slice index (for lambda)
    int k = start_k + (int)gen_idx;  // Current processing position

    int nk = nv_ordered(k);
    double lambda_k = lambda(original_k);

    // Random initialization of points for current slice
    uvec indices = randi<uvec>(nk, distr_param(0, N - 1));
    mat Pnk = ts.rows(indices);

    // Perform T iterations for current slice
    Pnk = seqSlicedRP_parallel_cpp(Pnk, Pnc, trts, ts, weights, lambda_k, T, n_cores);

    // Update accumulated points
    Pnc = join_vert(Pnc, Pnk);
    nc += nk;

    Rcpp::Rcout << "Slice " << (original_k + 1) << "/" << total_slices << " complete" << std::endl;
  }

  // Return result
  return Rcpp::List::create(
    Rcpp::Named("Pn") = Pnc,
    Rcpp::Named("slicenumber") = slicenumber
  );
}
