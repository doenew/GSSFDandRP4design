#include <RcppArmadillo.h>
#include <RcppParallel.h>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppParallel)]]

using namespace Rcpp;
using namespace RcppParallel;
using namespace arma;


// Helper function to find indices where slicenumber equals a specific value
std::vector<int> find_same_slice_indices(const arma::ivec& slicenumber, int target_slice) {
  std::vector<int> indices;
  for (int i = 0; i < slicenumber.n_elem; i++) {
    if (slicenumber(i) == target_slice) {
      indices.push_back(i);
    }
  }
  return indices;
}

// Main function for sliced RP parallel computation with weights
// [[Rcpp::export]]
arma::mat slicedRP_parallel_cpp(const arma::mat& Pn, const arma::mat& trts,
                                const arma::mat& ts, const arma::ivec& slicenumber,
                                const arma::vec& weights, double lambda, int n_cores) {

  int n = Pn.n_rows;    // Number of representative points
  int p = Pn.n_cols;    // Number of quantitative variables
  int N = ts.n_rows;    // Number of training samples

  // Validate weights dimension
  if (weights.n_elem != N) {
    Rcpp::stop("Length of weights must equal number of training samples");
  }

  // Initialize output matrix
  mat Pnnew(n, p, fill::zeros);

  // Pre-compute slice information
  int K = max(slicenumber);  // Number of slices
  std::vector<std::vector<int>> slice_indices(K);

  for (int k = 0; k < K; k++) {
    slice_indices[k] = find_same_slice_indices(slicenumber, k + 1);
  }

  // Parallel computation using OpenMP
#pragma omp parallel for num_threads(n_cores)
  for (int i = 0; i < n; i++) {
    // ============ Compute xdy and normxy ============
    rowvec pn_row = Pn.row(i);

    // Compute xdy = Pn[i,] - trts
    mat xdy(p, N);
    for (int j = 0; j < N; j++) {
      for (int k = 0; k < p; k++) {
        xdy(k, j) = pn_row(k) - trts(k, j);
      }
    }

    // Compute normxy = sqrt(colSums(xdy * xdy))
    vec normxy(N);
    for (int j = 0; j < N; j++) {
      double sum_sq = 0.0;
      for (int k = 0; k < p; k++) {
        double val = xdy(k, j);
        sum_sq += val * val;
      }
      double norm_val = sqrt(sum_sq);
      normxy(j) = (norm_val < 1e-14) ? 1.0 : norm_val;
    }

    // ============ Compute xdx and normxx ============
    mat xdx(n, p);
    for (int j = 0; j < n; j++) {
      for (int k = 0; k < p; k++) {
        xdx(j, k) = pn_row(k) - Pn(j, k);
      }
    }

    // Compute normxx = sqrt(rowSums(xdx * xdx))
    vec normxx(n);
    for (int j = 0; j < n; j++) {
      double sum_sq = 0.0;
      for (int k = 0; k < p; k++) {
        double val = xdx(j, k);
        sum_sq += val * val;
      }
      double norm_val = sqrt(sum_sq);
      normxx(j) = (norm_val < 1e-14) ? 1.0 : norm_val;
    }

    // Normalize xdx = xdx / normxx
    for (int j = 0; j < n; j++) {
      double inv_norm = 1.0 / normxx(j);
      for (int k = 0; k < p; k++) {
        xdx(j, k) *= inv_norm;
      }
    }

    // ============ Compute weighted update point ============
    // Compute mean(weights / normxy)
    double mean_weights_normxy = 0.0;
    for (int j = 0; j < N; j++) {
      mean_weights_normxy += weights(j) / normxy(j);
    }
    mean_weights_normxy /= N;

    // Avoid division by zero
    if (mean_weights_normxy < 1e-14) {
      mean_weights_normxy = 1.0;
    }

    // Compute colMeans(ts * weights / normxy)
    rowvec ts_weights_normxy_mean(p, fill::zeros);
    for (int j = 0; j < N; j++) {
      double weight_norm = weights(j) / normxy(j);
      for (int k = 0; k < p; k++) {
        ts_weights_normxy_mean(k) += ts(j, k) * weight_norm;
      }
    }
    ts_weights_normxy_mean /= N;

    // Compute colMeans(xdx[same_slice_indices,])
    int current_slice = slicenumber(i) - 1;  // Convert to 0-based index
    const std::vector<int>& same_slice_rows = slice_indices[current_slice];
    int n_same_slice = same_slice_rows.size();

    rowvec same_slice_mean(p, fill::zeros);
    if (n_same_slice > 0) {
      for (int idx = 0; idx < n_same_slice; idx++) {
        int row_idx = same_slice_rows[idx];
        for (int k = 0; k < p; k++) {
          same_slice_mean(k) += xdx(row_idx, k);
        }
      }
      same_slice_mean /= n_same_slice;
    }

    // Compute colMeans(xdx) - overall mean
    rowvec xdx_mean(p, fill::zeros);
    for (int j = 0; j < n; j++) {
      for (int k = 0; k < p; k++) {
        xdx_mean(k) += xdx(j, k);
      }
    }
    xdx_mean /= n;

    // Final update formula with weights:
    // update = 1 / mean(weights / normxy) *
    //          (colMeans(ts * weights / normxy) +
    //           (1 - lambda) * colMeans(xdx[same_slice,]) +
    //           lambda * colMeans(xdx))
    rowvec update(p);
    double inv_mean_weights_normxy = 1.0 / mean_weights_normxy;

    for (int k = 0; k < p; k++) {
      update(k) = inv_mean_weights_normxy *
        (ts_weights_normxy_mean(k) +
        (1.0 - lambda) * same_slice_mean(k) +
        lambda * xdx_mean(k));
    }

    // Save result
    for (int k = 0; k < p; k++) {
      Pnnew(i, k) = update(k);
    }
  }

  return Pnnew;
}
