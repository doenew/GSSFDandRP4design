#include <Rcpp.h>
#include <cmath>
#include <limits>
#include <algorithm>

using namespace Rcpp;

//' Calculate Uniformity Criteria (UNICRI) for Experimental Design
 //'
 //' This function calculates five uniformity criteria between a design matrix
 //' and a target region. It's optimized with C++ for performance.
 //'
 //' @param design A numeric matrix representing the experimental design points
 //' @param region A numeric matrix representing the target region
 //' @return A data frame with five criteria: mu, sd, RMSD, MaD, MiD
 //' @export
 // [[Rcpp::export]]
 DataFrame unicri_cpp(NumericMatrix design, NumericMatrix region) {
   int n_design = design.nrow();   // Number of design points
   int n_region = region.nrow();   // Number of region points
   int p = design.ncol();          // Dimension of points

   // 1. Calculate mu distance: Euclidean distance between centroids
   double mud = 0.0;
   NumericVector design_mean(p, 0.0);
   NumericVector region_mean(p, 0.0);

   // Calculate column means for design
   for (int j = 0; j < p; j++) {
     for (int i = 0; i < n_design; i++) {
       design_mean[j] += design(i, j);
     }
     design_mean[j] /= n_design;
   }

   // Calculate column means for region
   for (int j = 0; j < p; j++) {
     for (int i = 0; i < n_region; i++) {
       region_mean[j] += region(i, j);
     }
     region_mean[j] /= n_region;
   }

   // Calculate Euclidean distance between centroids
   for (int j = 0; j < p; j++) {
     double diff = design_mean[j] - region_mean[j];
     mud += diff * diff;
   }
   mud = std::sqrt(mud);

   // 2. Calculate sd distance: Euclidean distance between standard deviations
   double sdd = 0.0;
   NumericVector design_sd(p, 0.0);
   NumericVector region_sd(p, 0.0);

   // Calculate standard deviations for design
   for (int j = 0; j < p; j++) {
     double sum_sq = 0.0;
     for (int i = 0; i < n_design; i++) {
       double diff = design(i, j) - design_mean[j];
       sum_sq += diff * diff;
     }
     design_sd[j] = std::sqrt(sum_sq / (n_design - 1));
   }

   // Calculate standard deviations for region
   for (int j = 0; j < p; j++) {
     double sum_sq = 0.0;
     for (int i = 0; i < n_region; i++) {
       double diff = region(i, j) - region_mean[j];
       sum_sq += diff * diff;
     }
     region_sd[j] = std::sqrt(sum_sq / (n_region - 1));
   }

   // Calculate Euclidean distance between standard deviations
   for (int j = 0; j < p; j++) {
     double diff = design_sd[j] - region_sd[j];
     sdd += diff * diff;
   }
   sdd = std::sqrt(sdd);

   // 3. Calculate RMSD and MaD
   // Pre-transpose design for efficient distance calculations
   std::vector<std::vector<double>> tdesign(p, std::vector<double>(n_design));
   for (int i = 0; i < n_design; i++) {
     for (int j = 0; j < p; j++) {
       tdesign[j][i] = design(i, j);
     }
   }

   NumericVector drd(n_region);  // Minimum squared distances
   double sum_drd = 0.0;
   double max_sqrt_drd = 0.0;

   // For each point in region, find minimum squared distance to design points
   for (int r = 0; r < n_region; r++) {
     double min_dist_sq = std::numeric_limits<double>::max();

     for (int d = 0; d < n_design; d++) {
       double dist_sq = 0.0;
       for (int j = 0; j < p; j++) {
         double diff = region(r, j) - tdesign[j][d];
         dist_sq += diff * diff;
       }
       if (dist_sq < min_dist_sq) {
         min_dist_sq = dist_sq;
       }
     }

     drd[r] = min_dist_sq;
     sum_drd += min_dist_sq;
     double sqrt_drd = std::sqrt(min_dist_sq);
     if (sqrt_drd > max_sqrt_drd) {
       max_sqrt_drd = sqrt_drd;
     }
   }

   double RMSD = std::sqrt(sum_drd / n_region);
   double MaD = max_sqrt_drd;

   // 4. Calculate MiD: minimum distance between design points
   double MiD = std::numeric_limits<double>::max();

   for (int i = 0; i < n_design - 1; i++) {
     for (int k = i + 1; k < n_design; k++) {
       double dist_sq = 0.0;
       for (int j = 0; j < p; j++) {
         double diff = design(i, j) - design(k, j);
         dist_sq += diff * diff;
       }
       double dist = std::sqrt(dist_sq);
       if (dist < MiD) {
         MiD = dist;
       }
     }
   }

   // Return results as a DataFrame
   return DataFrame::create(
     Named("mu") = mud,
     Named("sd") = sdd,
     Named("RMSD") = RMSD,
     Named("MaD") = MaD,
     Named("MiD") = MiD
   );
 }
