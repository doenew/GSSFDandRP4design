#include <RcppArmadillo.h>
#include <RcppParallel.h>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <unordered_map>
#include <thread>  // Add this for hardware_concurrency

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppParallel)]]

using namespace Rcpp;
using namespace RcppParallel;
using namespace arma;

// Structure to store Indexlist data efficiently
struct IndexData {
  std::vector<uword> rows;
  std::vector<uword> mapped_ids;
  uword max_group_id;
};

// Worker class for parallel computation with optimizations
class WWCRPWorker : public Worker {
private:
  // Reference members - declared first to match initialization order
  const mat& Pn;                // n x p matrix (input)
  const mat& trts;              // p x N matrix (transposed ts)
  const mat& ts;                // N x p matrix (training samples)
  const vec& weights;           // length N vector
  double lambda;
  const vec& theta;
  const std::vector<IndexData>& index_data;
  mat& Pnnew;                   // n x p matrix (output)

  // Thread-local storage to avoid memory allocation in loops
  mat local_xdy;
  vec local_normxy;
  mat local_xdx;
  vec local_normxx;
  mat local_submean;

  // Problem dimensions
  uword n;
  uword p;
  uword N;

public:
  // Constructor with thread-local storage initialization
  // Initialization order must match declaration order
  WWCRPWorker(const mat& Pn, const mat& trts, const mat& ts,
              const vec& weights, double lambda, const vec& theta,
              const std::vector<IndexData>& index_data, mat& Pnnew)
    : Pn(Pn), trts(trts), ts(ts), weights(weights),
      lambda(lambda), theta(theta),
      index_data(index_data), Pnnew(Pnnew),
      n(Pn.n_rows), p(Pn.n_cols), N(ts.n_rows) {

    // Initialize thread-local storage with correct dimensions
    local_xdy.set_size(p, N);
    local_normxy.set_size(N);
    local_xdx.set_size(n, p);
    local_normxx.set_size(n);

    // Find maximum number of groups for submean matrix
    uword max_groups = 0;
    for (const auto& data : index_data) {
      if (data.max_group_id > max_groups) {
        max_groups = data.max_group_id;
      }
    }
    local_submean.set_size(max_groups > 0 ? max_groups : 1, p);
  }

  // Main operator for parallel computation
  void operator()(std::size_t begin, std::size_t end) {
    for (uword i = begin; i < end; i++) {
      const rowvec& pn_row = Pn.row(i);

      // Compute distances to training samples
      // Compute xdy = Pn[i,] - trts
      for (uword j = 0; j < N; j++) {
        for (uword k = 0; k < p; k++) {
          local_xdy(k, j) = pn_row(k) - trts(k, j);
        }
      }

      // Compute normxy = sqrt(colSums(xdy * xdy))
      for (uword j = 0; j < N; j++) {
        double sum_sq = 0.0;
        for (uword k = 0; k < p; k++) {
          double val = local_xdy(k, j);
          sum_sq += val * val;
        }
        local_normxy(j) = sqrt(sum_sq);
        if (local_normxy(j) < 1e-14) local_normxy(j) = 1.0;
      }

      // Compute distances to other representative points
      // Compute xdx = Pn[i,] - Pn
      for (uword j = 0; j < n; j++) {
        for (uword k = 0; k < p; k++) {
          local_xdx(j, k) = pn_row(k) - Pn(j, k);
        }
      }

      // Compute normxx = sqrt(rowSums(xdx * xdx))
      for (uword j = 0; j < n; j++) {
        double sum_sq = 0.0;
        for (uword k = 0; k < p; k++) {
          double val = local_xdx(j, k);
          sum_sq += val * val;
        }
        local_normxx(j) = sqrt(sum_sq);
        if (local_normxx(j) < 1e-14) local_normxx(j) = 1.0;
      }

      // Normalize xdx = xdx / normxx
      for (uword j = 0; j < n; j++) {
        double inv_norm = 1.0 / local_normxx(j);
        for (uword k = 0; k < p; k++) {
          local_xdx(j, k) *= inv_norm;
        }
      }

      // Process groups within subdesigns
      const IndexData& idx_data = index_data[i];
      uword n_entries = idx_data.rows.size();

      // Use unordered_map for faster group lookup
      std::unordered_map<uword, std::vector<uword>> groups;
      for (uword r = 0; r < n_entries; r++) {
        uword mapped_id = idx_data.mapped_ids[r];
        uword row_idx = idx_data.rows[r];
        groups[mapped_id].push_back(row_idx);
      }

      uword n_unique_groups = groups.size();

      // Compute column means for each group
      uword group_idx = 0;
      local_submean.zeros();

      for (const auto& pair : groups) {
        const std::vector<uword>& rows = pair.second;
        uword n_rows_in_group = rows.size();

        if (n_rows_in_group > 0) {
          // Sum all rows in the group
          for (uword r = 0; r < n_rows_in_group; r++) {
            uword row_idx = rows[r];
            for (uword k = 0; k < p; k++) {
              local_submean(group_idx, k) += local_xdx(row_idx, k);
            }
          }

          // Divide by number of rows to get mean
          double inv_n_rows = 1.0 / n_rows_in_group;
          for (uword k = 0; k < p; k++) {
            local_submean(group_idx, k) *= inv_n_rows;
          }
        }

        group_idx++;
      }

      // Compute update point
      // Compute mean(weights/normxy)
      double mean_inv_normxy = 0.0;
      for (uword j = 0; j < N; j++) {
        mean_inv_normxy += weights(j) / local_normxy(j);
      }
      mean_inv_normxy /= N;

      if (mean_inv_normxy < 1e-14) {
        mean_inv_normxy = 1.0;
      }

      // Compute colMeans(ts * weights / normxy)
      rowvec ts_normxy_mean(p, fill::zeros);
      for (uword j = 0; j < N; j++) {
        double inv_norm = weights(j) / local_normxy(j);
        for (uword k = 0; k < p; k++) {
          ts_normxy_mean(k) += ts(j, k) * inv_norm;
        }
      }
      ts_normxy_mean /= N;

      // Compute colSums(theta * submean)
      rowvec theta_submean_sum(p, fill::zeros);
      if (theta.n_elem >= n_unique_groups) {
        for (uword g = 0; g < n_unique_groups; g++) {
          double theta_val = theta(g);
          for (uword k = 0; k < p; k++) {
            theta_submean_sum(k) += theta_val * local_submean(g, k);
          }
        }
      }

      // Compute colMeans(xdx)
      rowvec xdx_mean(p, fill::zeros);
      for (uword j = 0; j < n; j++) {
        for (uword k = 0; k < p; k++) {
          xdx_mean(k) += local_xdx(j, k);
        }
      }
      xdx_mean /= n;

      // Final update formula
      double inv_mean = 1.0 / mean_inv_normxy;
      for (uword k = 0; k < p; k++) {
        Pnnew(i, k) = inv_mean * (ts_normxy_mean(k) +
          (1.0 - lambda) * theta_submean_sum(k) +
          lambda * xdx_mean(k));
      }
    }
  }
};

// Helper function to convert R List to optimized C++ structure
std::vector<IndexData> convertIndexListOptimized(const List& Indexlist_R) {
  uword n = Indexlist_R.size();
  std::vector<IndexData> index_data(n);

  for (uword i = 0; i < n; i++) {
    NumericMatrix idx_mat = Indexlist_R[i];
    uword n_rows = idx_mat.nrow();

    IndexData data;
    data.max_group_id = 0;

    if (n_rows > 0) {
      data.rows.reserve(n_rows);
      data.mapped_ids.reserve(n_rows);

      for (uword r = 0; r < n_rows; r++) {
        // R indices start from 1, C++ from 0
        data.rows.push_back(static_cast<uword>(idx_mat(r, 0)) - 1);
        uword mapped_id = static_cast<uword>(idx_mat(r, 1));
        data.mapped_ids.push_back(mapped_id);

        if (mapped_id > data.max_group_id) {
          data.max_group_id = mapped_id;
        }
      }
    }

    index_data[i] = data;
  }

  return index_data;
}

// Main C++ function with optimizations
// [[Rcpp::export]]
arma::mat wwCRP_parallel_cpp(const arma::mat& Pn, const arma::mat& trts,
                             const arma::mat& ts, const arma::vec& weights,
                             double lambda, const arma::vec& theta,
                             const Rcpp::List& Indexlist_R,
                             int n_cores = 0, int chunk_size = 0) {

  // Check for user interrupt
  Rcpp::checkUserInterrupt();

  uword n = Pn.n_rows;
  uword p = Pn.n_cols;

  // Convert Indexlist data to optimized structure
  std::vector<IndexData> index_data = convertIndexListOptimized(Indexlist_R);

  // Initialize output matrix
  mat Pnnew(n, p, fill::zeros);

  try {
    // Create worker
    WWCRPWorker worker(Pn, trts, ts, weights, lambda, theta, index_data, Pnnew);

    // Determine optimal chunk size
    uword actual_chunk_size;
    if (chunk_size > 0) {
      actual_chunk_size = static_cast<uword>(chunk_size);
    } else {
      // Auto-calculate chunk size without RcppParallel thread function
      // Use system hardware concurrency as fallback
      unsigned int hardware_threads = std::thread::hardware_concurrency();
      uword max_threads = (hardware_threads > 0) ? static_cast<uword>(hardware_threads) : 2;

      if (n_cores > 0 && static_cast<unsigned int>(n_cores) < hardware_threads) {
        max_threads = static_cast<uword>(n_cores);
      }

      actual_chunk_size = std::max<uword>(32, n / (max_threads * 4));
    }

    // Use appropriate parallel strategy
    if (n < 100) {
      // Serial computation for small n
      worker(0, static_cast<std::size_t>(n));
    } else {
      // Parallel computation with optimized chunk size
      parallelFor(0, static_cast<std::size_t>(n), worker, actual_chunk_size);
    }

  } catch(const std::exception& e) {
    Rcpp::stop("Error in parallel computation: %s", e.what());
  } catch(...) {
    Rcpp::stop("Unknown error in parallel computation");
  }

  return Pnnew;
}
